package Devices;


/**
 * Clase utilizada en el manejo de la camara
 *  @author Luis Leal
 */
public class Camara {

	public Camara() {
	}

	/**
	 *  Funcion que toma una foto
	 *  @return ubicacion de la foto dentro del dispositivo,null si no se toma foto
	 */
	public static String tomarFoto() {
	}
}
