package Devices;


/**
 * Clase utilizada para el manejo de servicios de ubicacion GPS
 *  @author Luis Leal
 */
public class Ubicacion {

	public Ubicacion() {
	}

	public com.codename1.location.Location obtenerUbicacionActual() {
	}
}
