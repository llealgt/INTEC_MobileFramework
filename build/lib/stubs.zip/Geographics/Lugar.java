package Geographics;


/**
 * 
 *  @author Luis Leal
 */
public class Lugar {

	public Lugar(double doubleLongitud, double doubleLatitud) {
	}

	public Lugar(java.util.Hashtable registro) {
	}

	public Lugar(double doubleLongitud, double doubleLatitud, String strNombre) {
	}

	public double getDoubleLongitud() {
	}

	public void setDoubleLongitud(double doubleLongitud) {
	}

	public double getDoubleLatitud() {
	}

	public void setDoubleLatitud(double doubleLatitud) {
	}

	public String getStrNombre() {
	}

	public void setStrNombre(String strNombre) {
	}

	public static java.util.Vector obtenerLugaresDesdeJSON(java.util.Vector resultadoJSON) {
	}

	public static void ubicarLugaresEnMapa(java.util.Vector lugares, com.codename1.maps.MapComponent mapa) {
	}
}
