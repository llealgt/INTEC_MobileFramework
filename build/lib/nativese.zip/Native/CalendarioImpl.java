package Native;

public class CalendarioImpl implements Native.Calendario{
    public int agregarEventoCalendarioDefault(String param, String param1, String param2, long param3, long param4) {
        return 0;
    }

    public int agregarEventoCalendarioEspecifico(int param, String param1, String param2, String param3, long param4, long param5) {
        return 0;
    }

    public String obtenerCalendarios() {
        return null;
    }

    public boolean isSupported() {
        return false;
    }

}
